
from django.shortcuts import render,redirect
from .models import Employee
from .forms import EmployeeForm
from django import views

# Create your views here.
class Employee_view(views.View):
    template_name='app2/employee.html'
    form=EmployeeForm


    def get(self,request):
        form=self.form()
        return render(request,template_name=self.template_name,context={'form':form})
    def post(self,request):
        form=self.form(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show')
        return render(request,template_name=self.template_name,context={'form':form})
class Show_view(views.View):
    template_name='app2/show.html'

    def get(self,request):
        data=Employee.objects.all()
        return render(request,template_name=self.template_name,context={'data':data})


class Update_view(views.View):
    form=EmployeeForm
    def get(self,request,pk):
        data=Employee.objects.get(id=pk)
        form= self.form(instance=data)
        return render(request,template_name='app2/employee.html',context={'form':form})

    def post(self,request,pk):
        data=Employee.objects.get(id=pk)
        form=self.form(request.POST,instance=data)
        if form.is_valid():
            form.save()
            return redirect('show')
        return render(request,template_name='app2/employee.html',context={'form':form})

class delete_view(views.View):
    template_name='app1/delete.html'
    def get(self,request,pk):
        data=Employee.objects.get(id=pk)
        return render(request, template_name=self.template_name, context={'data':data})

    def post(self,request,pk):
        data = Employee.objects.get(id=pk)
        data.delete()
        return redirect('show')

