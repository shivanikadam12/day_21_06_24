from django.db import models
class Employee(models.Model):
    id=models.IntegerField()
    name=models.CharField(max_length=100)
    company=models.CharField(max_length=50)
    email_id=models.EmailField(unique=True)
    department=models.CharField(max_length=50)
    date_of_joining=models.DateField()
    status=models.CharField(max_length=50)
    project_domain=models.CharField(max_length=50)

    def __str__(self):
       return self.name