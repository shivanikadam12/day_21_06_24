from django.urls import path
from .views import *


urlpatterns=[
    path('form/',Employee_view.as_view(),name='form'),
    path('show/',Show_view.as_view(),name='show'),
    path('update/<int:pk>/',Update_view.as_view(),name='update'),
    path('delete/<int:pk>/',delete_view.as_view(),name='delete'),
]